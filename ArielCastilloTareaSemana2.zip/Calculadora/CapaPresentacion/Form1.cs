﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaLogica;

namespace CapaPresentacion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //try
            //{
           //     CLcalculadora cLcalculadora = new CLcalculadora();
           //     int result = cLcalculadora.MtdSumar(int.Parse(txtNum1.Text), int.Parse(txtNum2.Text));
           //     MessageBox.Show($"El resultado de la suma es: {result}", "Exitooooo", MessageBoxButtons.OK, MessageBoxIcon.Information);
          //  }
         //   catch (Exception ex)
          //  {
          //      if (txtNum1.Text == ** || txtNum2.Text == **)
          //      { MessageBoxShow("No se admiten valores en blanco, ERRORRRRR", MessageBoxButtons OK, MessageBoxIcon.Error); }

           //     else { MessageBoxShow("No se admiten valores en blanco"); }

        }
    }
}
